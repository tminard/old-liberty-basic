Tip of the day demonstration.
Submitted by Mike Bradbury, mike@karemi.fsnet.co.uk
Run TOTDPlatform.tkn for demonstration
The source code is included in the two .lba files.
The tips are contained in the TOTD.txt file, a copy of which is included in case you 'mess up' the original.
