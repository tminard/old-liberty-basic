[branch]
bmp name, Left, Right, Forward, Back